export class Todo {
    text: string
    done: boolean
    editMode: boolean
    id: number
}