import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { Todo } from '../models/todo.model';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.css']
})
export class TodoListComponent implements OnInit {

  todos: Todo[] = []
  constructor(private apiService: ApiService) { }

  ngOnInit() {
    this.apiService.fetchTodos()
      .subscribe(todos => {
        todos.forEach(todo => {
          todo.editMode = false
          this.todos.push(todo)
        })
        console.log(this.todos)
      })
  }

  newTodoForm = new FormGroup({
    text: new FormControl(null, Validators.required),
    done: new FormControl(false)
  })
  onNewTodo() {
    this.apiService.onAddTodo(this.newTodoForm.value)
      .subscribe(todos => {
        this.apiService.fetchTodos()
          .subscribe(todos => {
            this.todos = []
            todos.forEach(todo => {
              todo.editMode = false
              this.todos.push(todo)
            })
            console.log(this.todos)
          })
      })
  }

  saveTodo(todo) {
    this.apiService.updateTodo(todo)
      .subscribe(todos => {
        this.apiService.fetchTodos()
          .subscribe(todos => {
            this.todos = []
            todos.forEach(todo => {
              todo.editMode = false
              this.todos.push(todo)
            })
            console.log(this.todos)
          })
      })
  }

  onDeleteTodo(id) {
    this.apiService.deleteTodo(id)
    .subscribe(todos => {
      this.todos = []
      todos.forEach(todo => {
        todo.editMode = false
        this.todos.push(todo)
      })
      console.log(this.todos)
    })
  }

}
