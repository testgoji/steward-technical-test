import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpRequest } from '@angular/common/http';
import { Todo } from './models/todo.model'

import { catchError } from 'rxjs/operators'

@Injectable()
export class ApiService {
  constructor(private http: HttpClient) { }

  headers: HttpHeaders = new HttpHeaders({
    'Content-Type': 'application/json'
  })
  
  onAddTodo(todo) {
    return this.http.post<Todo>('/api/todos', {
      text: todo.text,
      done: todo.done,
    }, {headers: this.headers})
  }

  fetchTodos() {
    return this.http.get<Todo[]>('/api/todos')
  }

  updateTodo(todo) {
    return this.http.post(`/api/todos/${todo._id}`, {
      text: todo.text,
      done: todo.done,
      id: todo._id
    }, {headers: this.headers})
  }

  deleteTodo(id) {
    return this.http.delete<Todo[]>(`/api/todos/${id}`)
  }
}
