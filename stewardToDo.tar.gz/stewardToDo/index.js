const express  = require('express')
const app      = express()
const mongoose = require('mongoose')
const bodyParser = require('body-parser')
const methodOverride = require('method-override')

mongoose.connect('mongodb://goji:goji123@ds117899.mlab.com:17899/gojitodo')

app.use(express.static(__dirname + '/dist'))
app.use(bodyParser.urlencoded({'extended':'true'}))
app.use(bodyParser.json())
app.use(bodyParser.json({ type: 'application/vnd.api+json' }))
app.use(methodOverride())

const Todo = mongoose.model('Todo', {
    text: String,
    done: Boolean
})

app.get('/api/todos', function(req, res) {
    Todo.find(function(error, todos) {
        if (error) {
            res.send(error)
        }
        res.json(todos)
    })
})

app.post('/api/todos/:id', function(req, res) {
    console.log(req.body.text)
    Todo.findByIdAndUpdate({_id: req.params.id}, {
        $set: {
            text: req.body.text,
            done: req.body.done
        }
    }, function(error, todo) {
        if (error) {
            res.send(error)
        }
        res.json(todo)
    })
})

app.post('/api/todos', function(req, res) {
    Todo.create({
        text: req.body.text,
        done: false
    }, function(error, todo) {
        if (error) {
            res.send(error)
        }
        Todo.find(function(err, todos) {
            if (error) {
                res.send(error)
            }
            res.json(todos)
        })
    })
})

app.delete('/api/todos/:id', function(req, res) {
    Todo.remove({
        _id : req.params.id
    }, function(error, todo) {
        if (error) {
            res.send(error)
        }
        Todo.find(function(error, todos) {
            if (error) {
                res.send(error)
            }
            res.json(todos)
        })
    })
})

app.listen(8080)
console.log("App listening on port 8080")